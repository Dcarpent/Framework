<?php
declare(strict_types=1);

namespace FastRoute;

use Throwable;

interface Exception extends Throwable
{
}
