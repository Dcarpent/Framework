<?php

return [
	'connectionString' => 'sqlite:' . BASE_PATH . '/database/db.sqlite',
];
